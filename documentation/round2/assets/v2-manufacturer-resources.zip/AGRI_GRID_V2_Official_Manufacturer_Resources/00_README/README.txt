AGRI-GRID V2 — OFFICIAL MANUFACTURER RESOURCE ARCHIVE
Collection date: 2026-10-16

Folders contain publicly hosted manufacturer CAD/drawings/datasheets where directly accessible, plus saved HTML snapshots for supplier pages when the exact model data sheet/CAD file was not exposed. source_file_manifest.csv has source URL, download status, file type/size, and SHA-256 for each item.

CRITICAL DESIGN HOLDS
1) WAAREE WS-20-12V solar panel: official shop page says 516 x 460 x 40 mm and 3.50 kg. L&T-SuFin listing for the nominally same model says 485 x 350 x 22 mm and 1.98 kg with electrical figures. This contradiction is unresolved. Do not freeze the solar bracket or MPPT compatibility from either listing. Get the actual product sticker and manufacturer datasheet before buying/mounting.
2) Fibox enclosure PC 200/150 HG, SKU 6011329: outside dimensions 255 x 180 x 150 mm, IP66/IP67, IK08, PC/TPE, -40 to +80 C. IP rating is for the enclosure under prescribed construction and sealing; it is not a rating for the AGRI-GRID assembly after drilling and adding glands.
3) EBYTE E22-900M22S: 20 x 14 mm module, 1.8-3.7V, SPI, 22 dBm transmitter listing. It is a solder-down module, not a carrier board. We must design/obtain a carrier, control 3.3V rail decoupling, follow the antenna feed/reference layout, and validate RF/regional compliance.
4) Genasun GV-5: exact candidate SKU GV-5-Li-14.2V-RETAIL for 4S LiFePO4. Confirm module revision, charge profile and cold-corrected panel Voc before buying. Controller is IP40 and must stay inside enclosure.
5) DFRobot SEN0602: single location probe, not a magical multi-depth sensor. It is RS485 Modbus; verify supply/current/registers and sensor calibration before final wiring.
6) DFRobot A02YYUW/SEN0311: 3-450cm range, 3cm blind zone and 60-degree beam. Do not use a narrow stilling tube inside the ultrasonic beam; use an open/wide acoustically clear protection arrangement and filter surface ripple in software.
7) Himax battery datasheet is a candidate envelope only. Confirm SKU, terminals, BMS, charging parameters, vent/expansion clearance and live stock with seller.
8) Solar mass and mounting height create a significant wind/bending load. Consider mounting solar low on the mast or on a separate short arm/base; no structural capacity claim is made here.

Recommended sequence:
A) Inspect the Fibox STEP in FreeCAD and validate internal wall/plate.
B) Inspect EBYTE footprint-download output; if it is a PDF rather than archive, use the module drawing from the official manual.
C) Use official ESP32 DevKitC dimension DXF; compare board revision to the unit purchased.
D) Lay out electronics on the Fibox plate using actual STEP body outlines; check service removal and cable bend radius.
E) Resolve the solar variant before modelling its mount.
F) Measure actual cable diameters and connector ends before drilling enclosure/gland holes.

SECOND ACQUISITION PASS (2026-10-16)
Added official Pololu D24V22Fx family STEP/dimension/drill resources for exact candidate regulators D24V22F5 (#2858) and D24V22F3 (#2857). These are mechanically traceable candidate parts, but their cost/import logistics are high versus local modules and thermal/current requirements must be tested.
Added official DFRobot DFR0845 isolated RS485-to-UART dimension drawing, schematic and datasheet. The outline drawing indicates about 37 x 47 mm PCB and 30 x 40 mm mounting-hole spacing; mounting component height and 12 V sensor-power capability still need a fit/load test.
The enclosure STEP, DevKitC DXF, EBYTE manual/footprint archive and Genasun controller datasheets are present. The exact solar panel remains a design hold due a manufacturer shop versus marketplace listing conflict. 
